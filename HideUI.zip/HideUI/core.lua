-- Created by Jakira of Elysium Project v0.1

local Frame = CreateFrame("Frame")
Frame:RegisterEvent("PLAYER_LOGIN")

Frame:SetScript("OnEvent", function(...)
MainMenuBarLeftEndCap:Hide()
MainMenuBarRightEndCap:Hide()

end)